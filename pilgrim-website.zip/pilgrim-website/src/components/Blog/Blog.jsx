function Blog() {
  return (
    <div>
      <h1>Blogs</h1>
    </div>
  );
}

export default Blog;
