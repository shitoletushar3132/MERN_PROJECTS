// App.js or your routing configuration file

import React from "react";

function App() {
  return (
   <div></div>
  );
}

export default App;
